﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IMC imc1;
            imc1 = new IMC();

            Console.WriteLine("Descubra o seu IMC a partir deste software");
            Console.WriteLine("Digite sua altura em metros (Ex: 1,80M)");
            imc1.setAltura(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o seu peso em kg");
            imc1.setPeso(double.Parse(Console.ReadLine()));

            imc1.operacao();
            imc1.compara();

            Console.WriteLine("Aqui está o seu imc: {0}",imc1.getR());
            


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex08
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Comparacao comparacao1;
            comparacao1 = new Comparacao();

            Console.WriteLine("Digite dois valores distintos e obtenha o maior na sua tela");
            Console.WriteLine("Digite o primeiro valor");
            comparacao1.setV1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o segundo valor");
            comparacao1.setV2(double.Parse(Console.ReadLine()));

            comparacao1.comp1();
            comparacao1.comp2();
          
            Console.WriteLine("O maior valor digitado foi: {0}", comparacao1.getM());
            


        }
    }
}

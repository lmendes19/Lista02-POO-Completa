﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pprojRetanguloPOO
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Retangulo retangulo;
            retangulo = new Retangulo();


            Console.WriteLine("Descubra o valor da area de um retangulo a partir de sua altura e base");
            Console.WriteLine("Digite o valor da altura do retangulo");
            retangulo.setN1(int.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o valor da base do retangulo");
            retangulo.setB2(int.Parse(Console.ReadLine()));

            retangulo.Multiplicar();

            Console.WriteLine("A area do seu retangulo com o valor da altura de {0} e da base {1}, é {2}",
                retangulo.getN1(),retangulo.getB2(),retangulo.getArea());

           


        }
    }
}

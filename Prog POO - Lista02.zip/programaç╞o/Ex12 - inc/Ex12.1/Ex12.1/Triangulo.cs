﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex12._1
{
    internal class Triangulo
    {
        private int a1;
        private int b1;
        private int c1;
        private string r;

        public Triangulo()
        {
            this.a1 = 0;
            this.b1 = 0;
            this.c1 = 0;
        }
        public Triangulo(double a1, double b2, double c1)
        {
            this.a1 = 0;
            this.b1 = 0;
            this.c1 = 0;
        }

        public void setA(int a1)
        {
            this.a1 = a1; 
        }
        public void setB(int b1)
        {
            this.b1 = b1;
        }
        public void setC(int c1)
        {
            this.c1 = c1; 
        }
        public int getA()
        {
            return this.a1; 
        }
        public int getB()
        {
            return this.b1;
        }
        public int getC()
        {
            return this.c1;
        }
        public void Calcular()
        {
            if (this.a1 + this.b1 > this.c1 && this.a1 + this.c1 > this.b1 && this.b1 + this.c1 > this.a1)

                if (this.a1 == this.b1 && this.a1 == this.c1)
                {

                    r = "Triângulo Equilátero";
                }
                else
                if (this.a1 == this.b1 || this.a1 == this.c1 || this.b1 == this.c1)
                {
                    this.r = "Triângulo Isósceles";
                }
                else
                    this.r = "Triângulo Escaleno";
                else
                this.r = "Não Formam Triângulo";
        }
        public string getR()
        {
            return this.r;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pprojQuadradoPOO
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Quadrado quadrado1;
            quadrado1 = new Quadrado();

            Console.WriteLine("Calcula a area de um quadrado a partir deste software");
            Console.WriteLine("Digite o valor da primeira aresta");
            quadrado1.setA1(double.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o valor da segunda aresta");
            quadrado1.setA2(double.Parse(Console.ReadLine()));

            quadrado1.Multiplicar();

            Console.WriteLine("Area = {0}",
               quadrado1.getResultado());



        }
    }
}
